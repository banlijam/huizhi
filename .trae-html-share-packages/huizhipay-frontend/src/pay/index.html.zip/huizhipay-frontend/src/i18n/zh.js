window.i18nZh = {
  sidebar: {
    operations: '运营',
    onboarding: '入驻与合规',
    overview: '总览',
    factoring: '保理与结算',
    ledgerSplits: '账本与分账',
    settlements: '结算',
    riskAml: '风控与反洗钱',
    integrations: '集成',
    settings: '设置',
    restricted: '受限功能',
    bank: '银行账户',
    fx: 'FX 提现',
    locked: '持牌后开放',
    pci: '所有卡数据经令牌化处理，控制台绝不存储 CVV。'
  },
  pages: {
    onboarding: {
      title: '入驻与合规',
      description: '极简 KYB 流程与结算钱包绑定。'
    },
    merchant: {
      title: '商户仪表盘',
      description: '实现法币通道与链上目的地的全链路结算透明化。'
    },
    overview: {
      title: '指挥中心',
      description: '实时大盘、透明分账账本与清算倒计时。'
    },
    factoring: {
      title: '保理与结算',
      description: '管理保理额度、拒付敞口与 T+1 结算。'
    },
    settlements: {
      title: '结算',
      description: '追踪 T+1 结算状态与链上最终性。'
    },
    integrations: {
      title: '集成',
      description: '连接商业平台并管理实时数据同步。'
    },
    risk: {
      title: '风控与路由',
      description: '配置智能路由规则、反欺诈策略与团队成员。'
    },
    settings: {
      title: '设置',
      description: '管理账户偏好、团队与安全设置。'
    }
  },
  header: {
    balance: '可用余额',
    topup: '充值',
    langZh: '中文',
    langEn: 'English',
    nextSettlement: '下一笔 T+1 清算倒计时'
  },
  merchant: {
    title: '商户仪表盘',
    subtitle: '实现法币通道与链上目的地的全链路结算透明化。'
  },
  kpi: {
    todayVolume: {
      label: '今日总流水',
      vsYesterday: '较昨日'
    },
    netSettlement: {
      label: '净结算额',
      netYield: '净收益率'
    },
    conversionRate: {
      label: '转化率',
      silentApproval: '静默通过'
    },
    amlRisk: {
      label: '反洗钱风险评分',
      intercepted: 'Chainalysis 已拦截'
    }
  },
  payout: {
    label: '结算策略',
    title: '选择结算目的地',
    subtitle: '无需更改买家结算流程即可切换。',
    crypto: {
      option: '加密货币',
      desc: 'Polygon / Stellar 智能合约分账 → 冷钱包'
    },
    fiat: {
      option: '法币',
      desc: 'Stellar SEP-24 锚定 → 商业银行账户'
    }
  },
  ledger: {
    sectionLabel: '1:N 分账瀑布流',
    title: '虚拟账本',
    allGateways: '所有网关',
    exportCsv: '导出 CSV',
    table: {
      orderId: '订单号',
      fiatIn: '法币收入',
      geoGateway: '地域网关',
      feeSplit: '费用分成',
      chainDest: '链上目的地',
      chainalysisStatus: 'Chainalysis 状态',
      settlementTime: '清算时间'
    }
  },
  overview: {
    apiCalls: 'API 调用',
    successRate: '成功率',
    authVolume: '认证交易额',
    last24h: '过去 24 小时',
    vsLastPeriod: '较前一周期',
    last7Days: '7 天累计处理额',
    chartTitle: '7 日 3DS 使用量',
    chartDesc: '认证请求与成功认证的实时趋势',
    realtime: '实时',
    logTitle: '近期 3DS 日志',
    chart3dsRequests: '3DS 请求',
    chartApproved: '认证通过',
    weekdays: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
    table: {
      time: '时间',
      orderId: '订单 ID',
      card: '卡号',
      provider: '提供商',
      status: '状态',
      cavv: 'CAVV / ECI'
    }
  },
  controlRoom: {
    todayTitle: '今日大盘',
    todayCount: '今日成功交易',
    todayCountUnit: '笔',
    conversionRate: '转化率',
    todayVolume: '今日总流水',
    countdownTitle: '清算倒计时',
    countdownDesc: '距离下一笔 T+1 清算还有',
    countdownUnit: '小时',
    countdownNext: '下一笔清算预计到账',
    ledgerTitle: '透明分账账本',
    ledgerDesc: '每笔订单的 7:93 分账拆解，所见即所得。',
    ledgerExample: '示例：买家支付',
    ledgerFee: '绘智服务费',
    ledgerNet: '您的净收益',
    ledgerBuyer: '买家支付',
    ledgerTable: {
      orderId: '订单号',
      gross: '买家支付',
      fee: '服务费 (7%)',
      net: '净收益 (93%)',
      status: '状态',
      time: '时间'
    },
    trendTitle: '7 日交易与转化趋势',
    statusSettled: '已结算',
    statusPending: '待清算'
  },
  onboarding: {
    stepperTitle: 'KYB 入驻进度',
    step1: '基本信息',
    step2: '营业执照',
    step3: '法人信息',
    step4: '结算偏好',
    formTitle: '极简入驻表单',
    formDesc: '无需几十页 PDF，4 步即可完成合规审核。',
    company: '公司名称',
    country: '注册国家',
    licenseNo: '营业执照编号',
    licenseUpload: '上传营业执照',
    licenseUploadHint: '拖拽文件至此或点击上传（PDF / JPG / PNG）',
    legalRep: '法人姓名',
    idNo: '法人证件号',
    settlementPref: '结算偏好',
    prefCrypto: '加密货币 (USDT / Polygon)',
    prefFiat: '法币电汇',
    prev: '上一步',
    next: '下一步',
    submit: '提交审核',
    statusTitle: 'KYB 审核状态',
    statusDraft: '草稿中',
    statusPending: '审核中',
    statusApproved: '已通过',
    statusRejected: '未通过',
    submittedAt: '提交时间',
    reviewedAt: '审核时间',
    walletTitle: '结算钱包绑定',
    walletDesc: '绑定后，T+1 净收益将自动结算至该地址。',
    walletBound: '当前结算地址',
    walletNetwork: '网络',
    walletType: '类型',
    walletChange: '更换',
    connectMetamask: '连接 MetaMask 授权',
    metamaskDesc: '一键授权绑定 Polygon 提现地址',
    stellarLabel: '或手动输入 Stellar 地址',
    stellarPlaceholder: '以 G 开头的 56 位地址',
    bindStellar: '绑定 Stellar 地址',
    installMetamask: '未检测到 MetaMask，请先安装钱包插件。',
    fieldRequired: '请完整填写必填项',
    submittedHint: '已提交审核，请等待人工审核结果',
    approvedHint: '审核已通过，功能已全面开放',
    rejectedHint: '审核未通过，请修改后重新提交',
    edit: '修改',
    resubmit: '重新提交'
  },
  factoring: {
    chargebackRate: '拒付率',
    factoringLimit: '保理额度',
    pendingNet: '待结算净额',
    belowThreshold: '低于 1.0% 风险阈值',
    used: '已使用 $28,200',
    next48h: '未来 48 小时',
    tableTitle: '即将到账的 T+1 结算',
    tableDesc: '扣除处理费与滚动准备金后的预计净额',
    channels: {
      visaNa: 'Visa · 北美',
      mastercardEu: 'Mastercard · 欧洲',
      localApac: '本地收单 · APAC'
    },
    table: {
      id: '结算 ID',
      date: '到账日',
      channel: '通道',
      gross: '交易总额',
      fees: '费用',
      net: '预计净额',
      status: '状态'
    },
    status: {
      processing: '处理中',
      locked: '已锁定',
      estimated: '预估'
    }
  },
  integrations: {
    running: '运行中',
    disabled: '未启用',
    shopifyDesc: '同步订单、退款与 3DS 验证状态。',
    woocommerceDesc: '通过安全 Webhook 接收实时交易事件。',
    connection: '连接状态',
    lastSync: '最近同步：2 分钟前',
    waiting: '等待连接',
    configure: '配置'
  },
  risk: {
    routing: '智能路由配置',
    routingDesc: '把复杂的智能路由做成规则开关，即时生效。',
    rules: '风控规则',
    rulesDesc: '规则修改会立即应用于所有实时授权请求。',
    strictMode: '严格反欺诈模式 (Strict Anti-Fraud Mode)',
    strictModeDesc: '开启后系统自动调高 Chainalysis KYT 拦截阈值，并强制所有订单进行 3DS2 验证。',
    strictModeBadge: '一键强化',
    blockPrepaid: '阻止预付卡',
    blockPrepaidDesc: '拦截预付型 BIN 发起的交易。',
    forceUs3ds: '美国 BIN 强制 3DS',
    forceUs3dsDesc: '对美国发卡行交易执行挑战流程。',
    kytScreening: 'Chainalysis KYT 实时拦截',
    kytScreeningDesc: '对资金来源地址实时筛查受制裁地址。',
    blockHighRiskRegion: '高风险地区拦截',
    blockHighRiskRegionDesc: '拦截来自高风险司法管辖区的交易。',
    team: '团队邀请',
    teamDesc: '集中管理控制台访问与最小权限角色。',
    invite: '邀请成员',
    table: {
      email: '邮箱',
      role: '角色',
      sent: '发送日期',
      status: '状态'
    },
    role: {
      admin: '运营管理员',
      analyst: '风控分析员',
      readonly: '只读财务'
    },
    status: {
      accepted: '已接受',
      pending: '待接受'
    }
  },
  topup: {
    title: '为 HuizhiPay 余额充值',
    desc: '资金确认后将自动计入可用余额。链上交易通常需要 1–3 次确认。',
    fiat: '法币',
    amount: '充值金额（USDT）',
    min: '最低 10 USDT，仅支持 TRC20 网络。',
    generate: '生成账单',
    waiting: '账单等待付款',
    invoiceId: '账单',
    network: '网络',
    copy: '复制充值地址',
    fiatDesc: '法币电汇通道正在审核中。请联系您的客户成功经理获取专属入金指引。'
  },
  status: {
    verified: '已验证',
    pending: '需审核',
    failed: '失败'
  },
  login: {
    title: '登录',
    subtitle: '商户控制台',
    email: '邮箱',
    password: '密码',
    totp: '双重认证码',
    totpHint: '请输入认证器应用中的6位验证码',
    remember: '记住我',
    forgot: '忘记密码？',
    signin: '登录',
    noAccount: '还没有账户？',
    signup: '创建账户'
  },
  register: {
    title: '创建账户',
    email: '邮箱',
    password: '密码',
    create: '创建账户'
  },
  forgot: {
    title: '重置密码',
    desc: '输入您的邮箱，我们将发送重置链接。',
    email: '邮箱',
    send: '发送重置链接'
  },
  verify: {
    email: {
      verifying: '正在验证您的邮箱...',
      success: '验证成功！',
      successDesc: '您的邮箱已验证。现在可以登录了。',
      login: '去登录',
      error: '验证失败',
      register: '重新注册'
    }
  },
  reset: {
    title: '重置密码',
    password: '新密码',
    confirm: '确认密码',
    submit: '重置密码',
    login: '返回登录'
  },
  payment: {
    nonCustodial: '非托管路由引擎',
    systemStatus: '系统状态：正常运行',
    rollingReserve: '(0% 滚动准备金)',
    buyTitle: '即时购买',
    buyTitleHighlight: '加密货币',
    buyDesc: '聚合 12+ 持牌网关的流动性。智能路由保证最优汇率。',
    buy: '购买',
    sell: '出售',
    desc: '入金',
    youPay: '支付',
    youReceive: '您接收',
    liveRate: '实时汇率',
    smartSplitter: '慧智智能分账器',
    transparent: '透明',
    autoRouted: '通过 MoonPay + Transak 自动路由',
    smartRouting: '智能订单路由与流动性聚合',
    merchantNet: '商户净收款',
    directWallet: '直接进入硬件钱包',
    settlementFinality: '结算周期：T+1 | 设计上非托管',
    checkout: '请求安全结算 API',
    secured3ds: '3DS2 安全保障',
    pciDss: 'PCI DSS L1 认证',
    micaLicensed: 'MiCA 持牌',
    poweredBy: '由慧智智能路由引擎 v5.5 驱动',
    copyright: '© 2026 慧智支付科技。非托管基础设施。',
    terms: '服务条款',
    privacy: '隐私政策',
    verifying3ds: '正在验证 3DS2 签名',
    authenticatingBank: '正在与发卡行进行身份验证...',
    secureAddress: '安全地址已生成',
    create2Desc: '基于 Tron 网络的 CREATE2 确定性地址',
    youSend: '您支付',
    youReceiveLabel: '您接收',
    network: '网络',
    depositAddress: '充值地址',
    addressExpiresIn: '地址将在以下时间后过期',
    sendExactly: '请准确发送',
    sendExactlyDesc: '等值金额至此地址。智能合约将在 1 个区块确认后自动兑换并转发至商户钱包。',
    cancel: '取消',
    sentFunds: '我已完成转账',
    addressCopied: '地址已复制到剪贴板！',
    currencies: {
      EUR: '欧元',
      USD: '美元',
      GBP: '英镑',
      ZAR: '南非兰特',
      AED: '阿联酋迪拉姆',
      ARS: '阿根廷比索',
      AUD: '澳大利亚元',
      BDT: '孟加拉塔卡',
      BRL: '巴西雷亚尔',
      CAD: '加拿大元',
      CHF: '瑞士法郎',
      CNY: '人民币',
      CZK: '捷克克朗',
      DKK: '丹麦克朗',
      EGP: '埃及镑',
      HKD: '港币',
      HUF: '匈牙利福林',
      IDR: '印尼盾',
      INR: '印度卢比',
      ILS: '以色列谢克尔',
      JPY: '日元',
      KRW: '韩元',
      MYR: '马来西亚林吉特',
      MXN: '墨西哥比索',
      NOK: '挪威克朗',
      NZD: '新西兰元',
      PKR: '巴基斯坦卢比',
      PHP: '菲律宾比索',
      PLN: '波兰兹罗提',
      RON: '罗马尼亚列伊',
      RUB: '俄罗斯卢布',
      SAR: '沙特里亚尔',
      SEK: '瑞典克朗',
      SGD: '新加坡元',
      THB: '泰铢',
      TRY: '土耳其里拉',
      UAH: '乌克兰格里夫纳',
      VND: '越南盾',
      HRK: '克罗地亚库纳',
      BGN: '保加利亚列弗',
      LKR: '斯里兰卡卢比'
    },
    cryptoNetworks: {
      TRC20: '波场 (TRC20)',
      Stellar: '恒星币',
      ERC20: '以太坊 (ERC20)',
      Bitcoin: '比特币',
      BitcoinCash: '比特币现金',
      Litecoin: '莱特币',
      Polygon: 'Polygon',
      BNBChain: '币安链 (BEP20)',
      Solana: 'Solana',
      Arbitrum: 'Arbitrum',
      Optimism: 'Optimism',
      Standalone: '网络'
    },
    labels: {
      fastest: '最快',
      lowFee: '低费用',
      secure: '安全'
    },
    gateway: {
      moonpayTransak: '通过 MoonPay + Transak 自动路由',
      mercuryoTransak: '通过 Mercuryo + Transak 自动路由',
      moonpayMercuryo: '通过 MoonPay + Mercuryo 自动路由'
    }
  },
  loading: '加载中...',
  toast: {
    copied: '充值地址已复制',
    invoiceGenerated: '充值账单已生成',
    invoiceError: '无法生成账单',
    integrationEnabled: '已启用',
    integrationDisabled: '已停用',
    integrationEnabledDesc: '实时同步将在数秒内开始。',
    integrationDisabledDesc: '新的事件将不再写入。',
    ruleEnabled: '已启用',
    ruleDisabled: '已停用',
    inviteCreated: '邀请链接已创建',
    notifications: '暂无新通知',
    walletBound: '结算钱包已绑定',
    walletMetamask: 'MetaMask 授权成功',
    walletStellar: 'Stellar 地址已绑定',
    walletInvalid: 'Stellar 地址格式不正确',
    onboardingSubmitted: 'KYB 资料已提交，等待审核',
    strictModeOn: '严格反欺诈模式已开启，所有订单强制 3DS2',
    strictModeOff: '严格反欺诈模式已关闭'
  }
};